import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class TotalScoresMappe extends Mapper<LongWritable, Text, Text, DoubleWritable>
{

	@Override
	protected void map(LongWritable key, Text value,Context context)
			throws IOException, InterruptedException 
	{
		
		String line=value.toString();
		String word[]=line.split("\t");
		String pname=word[0];
		double score=Double.parseDouble(word[1]);
		context.write(new Text(pname), new DoubleWritable(score));
	}
}
		
		/*String line = value.toString();
		String colArr[] = line.split("\t");
		Text cricketer = new Text();
		DoubleWritable score = new DoubleWritable();
		
		cricketer.set(colArr[0]);
		double sum=0;
		for(int i=1;i<=6;i++)
		{
			sum+= Double.parseDouble(colArr[i]);
		}		
		score.set(sum);
		context.write(cricketer,score);
	}
}*/
		
		
/*String line=value.toString();
Text player=new Text();
DoubleWritable score=new DoubleWritable();

StringTokenizer s= new StringTokenizer(line,"\t"); 
String name=s.nextToken();
player.set(name);
double count=0;
while(s.hasMoreTokens())
	{
	count+=Double.parseDouble(s.nextToken());
	}

	score.set(count);
	context.write(player,score);
}*/
	
	/*String line=value.toString();
	StringTokenizer s= new StringTokenizer(line,"\t"); 
	String name=s.nextToken();
	double count=0;
	while(s.hasMoreTokens())	{
		count+=Double.parseDouble(s.nextToken());
		}

		context.write(new Text(name), new DoubleWritable(count));
	}
	
	
	
	
	
}*/
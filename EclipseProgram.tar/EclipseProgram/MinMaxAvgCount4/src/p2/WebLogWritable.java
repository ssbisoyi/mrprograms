package p2;

import java.io.DataInput;
//import java.io.DataOutput;

import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.WritableComparable;

public class WebLogWritable implements WritableComparable<WebLogWritable>
{
   private Text siteURL,reqDate,timeStmp,IpAdrs;
   private IntWritable reqNo;
   
   		// Default Constructor
   			public WebLogWritable()
   			{
	          this.siteURL=new Text();
	          this.reqDate=new Text();
	          this.timeStmp=new Text();
	          this.IpAdrs=new Text();
	          this.reqNo=new IntWritable();
	                   
   			}
   			
   		//custom constructor
   			public WebLogWritable(Text URL,Text rdate,Text tstmp,Text Ip,IntWritable rno)
   			{
   				this.siteURL=URL;
   				this.reqDate=rdate;
   				this.timeStmp=tstmp;
   				this.IpAdrs=Ip;
   				this.reqNo=rno;
   				
   			}
   		// Setter method to set the values in the WebLog object

			public void setSiteURL(Text siteURL) {
				this.siteURL = siteURL;
			}

			public void setReqDate(Text reqDate) {
				this.reqDate = reqDate;
			}

			public void setTimeStmp(Text timeStmp) {
				this.timeStmp = timeStmp;
			}

			public void setIpAdrs(Text ipAdrs) {
				this.IpAdrs = ipAdrs;
			}

			public void setReqNo(IntWritable reqNo) {
				this.reqNo = reqNo;
			}
   			
   		// To get IP Address from WebLog Object
			
			public Text getIp()
			{
				return IpAdrs;
			}
			
		// Overriding default readfield method
		// It desirialization the byte data
			/*public void readField(DataInput in) throws Exception
			{
				siteURL.readFields(in);
				reqDate.readFields(in);
				timeStmp.readFields(in);
				IpAdrs.readFields(in);
				reqNo.readFields(in);
			}*/
		// it serialize object stream data into byte stream
			public void write(DataOutput out)throws IOException
			{
				siteURL.write(out);
				reqDate.write(out);
				timeStmp.write(out);
				IpAdrs.write(out);
				reqNo.write(out);
			}
			
			public int compareTo(WebLogWritable o)
			{
				if(IpAdrs.compareTo(o.IpAdrs)==0)
				{
					return timeStmp.compareTo(o.timeStmp);
				}
				else
				{
					return IpAdrs.compareTo(o.IpAdrs);
				}
					
			}
			
			public boolean equals(Object o)
			{
				if(o instanceof WebLogWritable)
				{
					WebLogWritable ot=(WebLogWritable)o;
					return IpAdrs.equals(ot.IpAdrs)&& timeStmp.equals(ot.timeStmp);
				}
				return false;
			}
			
           public int hashCode()
           {
        	   return IpAdrs.hashCode();
           }

		@Override
		public void readFields(DataInput in) throws IOException 
		{
		siteURL.readFields(in);
		reqDate.readFields(in);
		timeStmp.readFields(in);
		IpAdrs.readFields(in);
		reqNo.readFields(in);

			
			
			
		}

		/*public void set(IntWritable reqNo2, Text siteURL2, Text reqDate2,
				Text timeStmp2, Text ipAdrs2) {
			this.siteURL=siteURL2;
				this.reqDate=reqDate2;
				this.timeStmp=timeStmp2;
				this.IpAdrs=ipAdrs2;
				this.reqNo=reqNo2;
			// TODO Auto-generated method stub
			
		}*/
}

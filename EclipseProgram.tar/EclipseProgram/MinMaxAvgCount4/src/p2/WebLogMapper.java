package p2;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class WebLogMapper extends Mapper<LongWritable,Text,WebLogWritable,IntWritable>
{
	public static final IntWritable one=new IntWritable(1);
	private Text siteURL=new Text();
	private Text reqDate=new Text();
	private Text timeStmp=new Text();
	private Text IpAdrs=new Text();
	private IntWritable reqNo=new IntWritable();
	
	
	
    public void map(LongWritable key,Text value,Context con) throws IOException,InterruptedException
    {
    	String word[]=value.toString().split("\t");
    	reqNo.set(Integer.parseInt(word[0]));
    	siteURL.set(word[1]);
    	reqDate.set(word[2]);
    	timeStmp.set(word[3]);
    	IpAdrs.set(word[4]);
    	
    	WebLogWritable weblog=new WebLogWritable(siteURL,reqDate, timeStmp, IpAdrs,reqNo) ;
    	//weblog.set(reqNo,siteURL,reqDate,timeStmp,IpAdrs);
    	con.write(weblog, one);
    	
    }
}
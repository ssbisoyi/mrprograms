package p2;

import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;



public class WebLogDriver extends Configured{
	 
		
		public static void main(String[] args) throws Exception{
	//Configuration conf=new Configuration();
			Job j=new Job();
			
			j.setJarByClass(WebLogDriver.class);
			j.setMapperClass(WebLogMapper.class);
			j.setReducerClass(WebLogReducer.class);
			
			j.setOutputKeyClass(Text.class);
			j.setOutputValueClass(IntWritable.class);
			
			j.setMapOutputKeyClass(WebLogWritable.class);
			j.setMapOutputValueClass(IntWritable.class);
			
			
			j.setInputFormatClass(TextInputFormat.class);
			j.setOutputFormatClass(TextOutputFormat.class);
			
			FileInputFormat.addInputPaths(j,args[0]);
	        FileOutputFormat.setOutputPath(j,new Path(args[1]));
			System.exit(j.waitForCompletion(true)? 0:1);
			
		}

	}


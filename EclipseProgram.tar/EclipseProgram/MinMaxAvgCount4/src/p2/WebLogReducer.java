package p2;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class WebLogReducer extends Reducer<WebLogWritable,IntWritable,Text,IntWritable>
{
	private IntWritable result=new IntWritable();
	private Text temp=new Text();
	
	public void reduce(WebLogWritable key,Iterable<IntWritable> values,Context context)throws IOException,InterruptedException
	{
		int sum=0;
		temp=key.getIp();
		for(IntWritable val:values)
		{
			sum++;
		}
		result.set(sum);
		context.write(temp, result);
		
	}
			

}
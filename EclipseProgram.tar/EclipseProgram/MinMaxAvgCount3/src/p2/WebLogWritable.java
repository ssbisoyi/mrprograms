package p2;

import java.io.DataInput;
//import java.io.DataOutput;

import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.WritableComparable;

public class WebLogWritable implements WritableComparable<WebLogWritable>
{

	private LongWritable num1,num2;

	public LongWritable getNum1() {
		return num1;
	}

	public void setNum1(LongWritable num1) {
		this.num1 = num1;
	}

	public LongWritable getNum2() {
		return num2;
	}

	public void setNum2(LongWritable num2) {
		this.num2 = num2;
	}

	// Default Constructor
	public WebLogWritable()
	{

		this.num1=new LongWritable();
		this.num2=new LongWritable();

	}

	//custom constructor
	public WebLogWritable(LongWritable num1,LongWritable num2)
	{
		this.num1=num1;
		this.num2=num2;

	}



	// Overriding default readfield method
	// It desirialization the byte data
	// it serialize object stream data into byte stream
	public void write(DataOutput out)throws IOException
	{
		num1.write(out);
		num2.write(out);

	}

	@Override
	public void readFields(DataInput in) throws IOException {
		num1.readFields(in);
		num2.readFields(in);
	}
	
	public long get(){
		return this.num1.get()+this.num2.get();
	}

	@Override
	public int compareTo(WebLogWritable o) {
		return 0;
	}


}


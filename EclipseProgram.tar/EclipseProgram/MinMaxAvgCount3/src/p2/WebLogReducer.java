package p2;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class WebLogReducer extends Reducer<Text,WebLogWritable,Text,LongWritable>
{
	
	WebLogWritable weblog=new WebLogWritable();
	
	public void reduce(Text key,Iterable<WebLogWritable> values,Context context)throws IOException,InterruptedException
	{
		long sum=0;
		//temp=weblog.getNum1();
		//temp1=weblog.getNum2();
		//int sum=temp.get()+temp1.get();
		
		for(WebLogWritable val:values)
		{
			System.out.println(val.get());
			sum =sum+val.get();
		}
		//result.set(sum);
		context.write(key, new LongWritable(sum));
	}
			

}
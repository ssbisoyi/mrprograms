package p2;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class WebLogMapper extends Mapper<LongWritable,Text,Text,WebLogWritable>
{
	public static final LongWritable one=new LongWritable(1);
	private Text name=new Text();
	private LongWritable num1=new LongWritable();
	private LongWritable num2=new LongWritable();
	
	WebLogWritable weblog=new WebLogWritable() ;
	
	
    public void map(LongWritable key,Text value,Context con) throws IOException,InterruptedException
    {
    	String word[]=value.toString().split("\t");
    	name.set(word[0]);
    	num1.set(Long.parseLong(word[1]));
    	num2.set(Long.parseLong(word[2]));
    	
    	weblog.setNum1(num1);
    	weblog.setNum2(num2);
    	//WebLogWritable weblog=new WebLogWritable(num1,num2) ;
    	//weblog.set(reqNo,siteURL,reqDate,timeStmp,IpAdrs);
    	con.write(name, weblog);
    	
    }
}
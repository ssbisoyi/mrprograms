import java.io.IOException;

import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

public class WordCount extends Configured
{

		public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
		
		Job scoresJob = new Job();
		
		// Set job specific configuration parameters 
		scoresJob.setJobName("Cricket Scores"); // job name parameter
		scoresJob.setJarByClass(WordCount.class); // setJarByClass job tracker will distribute the tasks to task trackers.It will communicate with other systems inside the cluster to recognize your jar file.
		
		//Set input & Output paths
		FileInputFormat.addInputPaths(scoresJob,args[0]);
		FileOutputFormat.setOutputPath(scoresJob, new Path(args[1])); 
		
		// register Mapper & Reducer class to driver
		scoresJob.setMapperClass(WordMapper.class);
		scoresJob.setReducerClass(WordReducer.class);
				
		//Specify Mapper & Reducer output key value types
		scoresJob.setMapOutputKeyClass(Text.class);
		scoresJob.setMapOutputValueClass(DoubleWritable.class);
		scoresJob.setOutputKeyClass(Text.class);
		scoresJob.setOutputValueClass(DoubleWritable.class);
		
		//Need to mention Input format file.
		scoresJob.setInputFormatClass(TextInputFormat.class);
		scoresJob.setOutputFormatClass(TextOutputFormat.class);
		
		// Give status of the job while submitting to hadoop
		boolean success = scoresJob.waitForCompletion(true);
		System.exit(success ? 0 : 1);
	};
	

}
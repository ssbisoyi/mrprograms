import java.io.IOException;
import java.util.Iterator;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class WordReducer extends Reducer<Text, DoubleWritable, Text, DoubleWritable> 
{

	@Override
	protected void reduce(Text key, Iterable<DoubleWritable> values,Context context)throws IOException, InterruptedException
	{
	
	double tot=0;
	double count=0;
	double min = Double.MAX_VALUE;
	double max=0;
	Iterator<DoubleWritable> iterator=values.iterator();
	while (iterator.hasNext())
			{
		double value= iterator.next().get();
		tot+=value;
		count++;
		if(value<min){ min=value;}
		if (value>max){ max=value;}
		
			}
	context.write(key,new DoubleWritable(max));
	context.write(key,new DoubleWritable(min));
	context.write(key,new DoubleWritable(tot/count));
	
		}
	}
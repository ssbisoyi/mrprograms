import java.io.*;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
public class WordCountDriver 
{
	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException
	{
		//Configuration details w.r.t job and jar
		Configuration conf=new Configuration();
		@SuppressWarnings("deprecation")
		Job job=new Job(conf,"WORDCOUNT");
		job.setJarByClass(WordCountDriver.class);
		job.setMapperClass(TokenizerMapper.class);
		job.setCombinerClass(IntSumReducer.class);
		job.setReducerClass(IntSumReducer.class);
		//Final output key and value datatype details
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(IntWritable.class);
		//HDFS input and output path details
		FileInputFormat.addInputPath(job,new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		//How execution triggers
		System.exit(job.waitForCompletion(true) ? 0 : 1);
	}

}


public class newWordCount extends Configured {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

package wordcountnew;

public class newWordReducer {

}

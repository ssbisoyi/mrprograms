package wordcountnew;

public class newWordMapper {

}

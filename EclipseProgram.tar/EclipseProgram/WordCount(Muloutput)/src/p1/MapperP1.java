package p1;

import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MapperP1 extends Mapper<Object, Text,Text,MultiValueWritable>
{
	 
	private Text word=new Text();
	
	IntWritable one= new IntWritable(1);
	Text hai= new Text("Hello");
	
public void map (Object key,Text value, Context context) throws IOException, InterruptedException
{

	StringTokenizer str=new StringTokenizer(value.toString());
	while(str.hasMoreTokens())
	{
		word.set(str.nextToken());
		context.write(word, new MultiValueWritable(one));
		context.write(word,new MultiValueWritable(hai));
	}
	}
}



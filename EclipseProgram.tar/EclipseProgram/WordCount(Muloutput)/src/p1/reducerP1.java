package p1;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapreduce.Reducer;

public class reducerP1 extends Reducer<Text,MultiValueWritable, Text, Text>
{
public void reduce(Text key, Iterable<MultiValueWritable> value, Context context) throws IOException, InterruptedException	
	{
	Text result=new Text();
	int sum=0;
	StringBuilder requests=new StringBuilder();
	for(MultiValueWritable multivaluewritable: value)
	{
	Writable writable=multivaluewritable.get();
	if(writable instanceof IntWritable)
	{
	sum+=((IntWritable)writable).get();
	}
	
		
		//MultiValueWritable multivaluewritable= new MultiValueWritable();
		//Writable writable=multivaluewritable.get();
		//if(writable instanceof Text)
		//{
	else{
		requests.append((Text)writable).toString();
		requests.append("\t");
		}
	}
	
result.set(sum+"\t"+requests);

context.write(key, result);
}

}

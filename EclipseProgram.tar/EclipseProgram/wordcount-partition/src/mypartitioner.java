import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.Partitioner;

public class mypartitioner implements Partitioner<Text,IntWritable>{


	public void configure(JobConf arg0) {	}

	public int getPartition(Text key, IntWritable value, int setNumReducedTasks) 
	{
		String s=key.toString();
		System.out.println(s.length());
		if(s.length()==1){return 0;}
		if(s.length()==2){return 1;}
		if(s.length()==3){return 2;}
		if(s.length()==4){return 3;}
		else{return 4;}
		
	}

}

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

public class TotalScoresDriver extends Configured{

		public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
			
			Configuration conf=new Configuration();
		
		Job scoresJob = new Job(conf,"Reduce side joining");
		
		
		scoresJob.setJarByClass(TotalScoresDriver.class);
		
		MultipleInputs.addInputPath(scoresJob,new Path(args[0]),TextInputFormat.class, Cust_Data.class);
		MultipleInputs.addInputPath(scoresJob,new Path(args[1]),TextInputFormat.class, Order_Custid.class);
		
		
		FileOutputFormat.setOutputPath(scoresJob, new Path(args[2])); 
		
		// register Mapper & Reducer class to driver
		scoresJob.setMapperClass(Cust_Data.class);
		scoresJob.setMapperClass(Order_Custid.class);
		
		scoresJob.setReducerClass(ReducerJoin.class);
		
				//Specify Mapper & Reducer output key value types
		scoresJob.setMapOutputKeyClass(Text.class);
		scoresJob.setMapOutputValueClass(Text.class);
		scoresJob.setOutputKeyClass(Text.class);
		scoresJob.setOutputValueClass(Text.class);
		
		boolean success = scoresJob.waitForCompletion(true);
		System.exit(success ? 0 : 1);
	};
	

}
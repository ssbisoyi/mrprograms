import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
//import org.apache.hadoop.mapreduce.lib.join;

public class ReducerJoin extends Reducer<Text,Text,Text,Text>
{
public void reduce(Text key,Iterable<Text> values, Context context) throws IOException, InterruptedException
{
	String name="";
	//double tot=0;
	int count=0;
	for(Text t:values)
	{
	String cust[]=t.toString().split("\t");
	if(cust[0].equals("tab2"))
	count++;
	else if(cust[0].equals("tab1"))
		name=cust[1];
		String str1=String.format("%s\t%s",cust[0],cust[2]);
		String str2=String.format("%s\t%s",cust[1],cust[3]);
		context.write(new Text(str1),new Text(str2));
		
		
	}
	}
}




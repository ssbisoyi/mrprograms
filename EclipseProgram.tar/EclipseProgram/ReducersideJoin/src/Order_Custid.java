import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class Order_Custid extends Mapper<Object,Text,Text,Text> 
{
public void map(Object key, Text value, Context context) throws IOException, InterruptedException
{
	String record1=value.toString();
	String[] part1=record1.split("\\s+");
	context.write(new Text(part1[2]), new Text("tab2\t"+part1[3]));
	
}
}

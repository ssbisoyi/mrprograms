package demo1;
import java.util.*;
 
class X
{
	int i;
}

class hashsetdemo
	{
	public static void main(String []args)
		{
		HashSet<X> hsh = new HashSet<X> ();
		for (int i=0;i<5; i++)
			{
			X a=new X();
			a.i=i;
			hsh.add(a);
			}
		for(X b:hsh)
			{
		System.out.println(b.i);
			}
		}
	}